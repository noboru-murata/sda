### 中心極限定理
###    偶数が出る確率が奇数の出る確率の2倍となるサイコロを振ったときに
###    出る目の標本平均の分布を実験で確かめる 
set.seed(123)    # 乱数のシード値の指定
omega <- 1:6     # サイコロの出る目の集合
p <- rep(1:2, 3) # 出現確率の比 (奇数1:偶数2，正規化していなくてもよい)
(mu <- weighted.mean(omega, p)) # 理論上の平均
(sigma <- sqrt(weighted.mean(omega^2,p)-mu^2)) # 理論上の標準偏差
mymean <- function(n) # n回サイコロを振って出た目の標本平均を計算する関数
    mean(sample(omega, size=n, prob=p, replace=TRUE))
mc <- 1000 # Monte-Carlo実験の繰り返し回数
for(n in c(10,100,1000)){ # サンプル数を変えて実験
    xbars <- replicate(mc, mymean(n)) # 実験をmc回繰り返し標本平均を記録
    hist(sqrt(n)*(xbars - mu)/sigma, breaks=25, freq=FALSE,
         xlim=c(-3, 3), ylim=c(0,0.55),  
         col="orchid", border="slateblue",
         xlab=expression(sqrt(n)*(bar(X)[n]-mu)/sigma), main=paste0("n=",n))
    curve(dnorm, add=TRUE, col="orange", lwd=2) # 理論曲線を重ねる
}
