### 中心極限定理
###    ggplot2での描画
require(tidyverse) # パッケージの読み込み
set.seed(123)    # 乱数のシード値の指定
omega <- 1:6     # サイコロの出る目の集合
p <- rep(1:2, 3) # 出現確率の比 (奇数1:偶数2，正規化していなくてもよい)
(mu <- weighted.mean(omega, p)) # 理論上の平均
(sigma <- sqrt(weighted.mean(omega^2,p)-mu^2)) # 理論上の標準偏差
mymean <- function(n) # n回サイコロを振って出た目の標本平均を計算する関数
    mean(sample(omega, size=n, prob=p, replace=TRUE))
mc <- 1000 # Monte-Carlo実験の繰り返し回数
for(n in c(10,100,1000)){ # サンプル数を変えて実験
    mydf <- data.frame(
        xbar=replicate(mc, mymean(n))) # 同じ実験をmc回繰り返し標本平均を記録
    gg <- ggplot(mydf, aes(x=sqrt(n)*(xbar - mu)/sigma)) + 
        geom_histogram(aes(y=..density..),# binwidth=0.2,
                       colour="slateblue", fill="orchid", alpha=.6) +
        geom_density(colour="slateblue", alpha=.3) + # 実験値の分布の概形
        stat_function(fun=dnorm, colour="orange") +
        xlim(-3, 3) + ylim(0,0.6) + # 描画範囲を指定
        labs(x=expression(sqrt(n)*(bar(X)[n]-mu)/sigma),
             title=paste("n =", n))
    print(gg)
}
