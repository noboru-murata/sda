### dplyr::sample_n (個数を指定してサンプリングする)
sample_n(airquality, size=10)
### dplyr::sample_frac (比率を指定してサンプリングする)
sample_frac(airquality, size=0.05)
