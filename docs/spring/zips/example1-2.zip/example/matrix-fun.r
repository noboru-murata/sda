A <- matrix((1:6)*pi/2,2,3) # 行列の作成 (2x3行列)
sin(A) 
exp(A)
log(A)
