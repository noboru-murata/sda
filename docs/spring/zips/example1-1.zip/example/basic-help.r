### help関数の使い方
help(sin) # 三角関数のヘルプを見る
?log # help() の代わりに ? を使うことができる
### help.search関数の使い方
help.search("histogram") # ヒストグラムに関連する関数を探す
??random # help.search() の代わりに ?? を使うことができる
