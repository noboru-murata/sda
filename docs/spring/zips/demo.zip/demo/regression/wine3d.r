###
### wine data を 3D で表示
###
require(rgl)

## データの読み込み (欠損は表示から外す)
wine <- na.exclude(read.csv(file="wine.csv",row.names=1))

## 3D 表示
xyz <- wine[c("WRAIN","HRAIN","LPRICE2")]
timec <- heat.colors(nrow(wine),alpha=0.1) # 時間順に色付け
degr <- wine[,"DEGREES"] # 温度を球の大きさで
degr <- (degr-min(degr))/(max(degr)-min(degr))+1
plot3d(xyz, type="s", col=timec, radius=20*degr)
text3d(xyz+c(0,0,0.3),texts=rownames(wine))
play3d(spin3d(c(0, 0, 1), 15),duration=10) # 10秒回転
