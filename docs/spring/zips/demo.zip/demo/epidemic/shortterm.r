###
### 感染症の短期的な性質の lattice model による実験
###

### 数値実験のための関数の定義
## nxnの2次元場に抗体のある人とない人をランダムに配置
immune<-function(n,p) {
  tmp<-matrix(rbinom(n*n,1,p),n,n) # 1が抗体のない人
  class(tmp)<-"immune"
  return(tmp)
}

## 抗体の無い人を2次元に表示
plot.immune<-function(z) {
  n<-nrow(z)
  x<-rep(1:n,n)
  y<-rep(1:n,each=n)
  plot(1:n,1:n,type="n",xlab="",ylab="")
  points(x,y,col=z,pch=1,cex=1)
}

## ランダムに一人感染させる
outbreak<-function(z,plot=TRUE) {
  tmp<-which(z==1,arr.ind=T)
  idx<-tmp[sample(nrow(tmp),1),]
  if(plot) points(idx[1],idx[2],font=5,pch=240,cex=1,col="red");
  return(idx)
}

## 感染経路を表示
cluster<-function(z,col="blue") {
  n<-nrow(z)
  tmp<-matrix(0,n+1,n+1)
  tmp[1:n,1:n]<-z
  for(i in 1:n) {
    for(j in 1:n) {
      if(tmp[i,j]==1) {
        if(tmp[i+1,j]==1) segments(i,j,i+1,j,col=col,lwd=3);
	if(tmp[i,j+1]==1) segments(i,j,i,j+1,col=col,lwd=3);
      }
    }
  }
}

## 感染の状況を表示しながらシミュレート(遅い)
infection<-function(z,idx) {
  n<-nrow(z)
  z[idx[1],idx[2]]<-2
  tmpa<-matrix(0,n+2,n+2)
  tmpa[(1:n)+1,(1:n)+1]<-z
  dif<-1
  while(dif > 0) {
    dif<-0
    tmpb<-tmpa
    for(i in (1:n)+1) {
      for(j in (1:n)+1) {
        if(tmpa[i,j]==2) {
          if(tmpa[i+1,j]==1) {
            tmpb[i+1,j]<-2
            dif<-dif+1
	    segments((i-1),(j-1),(i+1-1),(j-1),col="red",lwd=3)
	  }
          if(tmpa[i-1,j]==1) {
            tmpb[i-1,j]<-2
            dif<-dif+1
            segments((i-1),(j-1),(i-1-1),(j-1),col="red",lwd=3)
          }
          if(tmpa[i,j+1]==1) {
            tmpb[i,j+1]<-2
            dif<-dif+1
            segments((i-1),(j-1),(i-1),(j+1-1),col="red",lwd=3)
          }
          if(tmpa[i,j-1]==1) {
            tmpb[i,j-1]<-2
            dif<-dif+1
            segments((i-1),(j-1),(i-1),(j-1-1),col="red",lwd=3)
          }
        }
      }  
    }
    tmpa<-tmpb
  }
  z<-tmpa[(1:n)+1,(1:n)+1]
  return(z)
}

## 感染経路に従って罹患する人をシミュレート
spread<-function(z,idx) {
  n<-nrow(z)
  z[idx[1],idx[2]]<-2
  tmpa<-matrix(0,n+2,n+2)
  tmpa[(1:n)+1,(1:n)+1]<-z
  dif<-1
  while(dif>0) {
    dif<-0
    for(i in (1:n)+1) {
      for(j in (1:n)+1) {
        if(tmpa[i,j]==2) {
          if(tmpa[i+1,j]==1) {
            tmpa[i+1,j]<-2
            dif<-dif+1
	    }
          if(tmpa[i,j+1]==1) {
            tmpa[i,j+1]<-2
            dif<-dif+1
          }
        }
      }
    }  
    for(i in (n:1)+1) {
      for(j in (n:1)+1) {
        if(tmpa[i,j]==2) {
          if(tmpa[i-1,j]==1) {
            tmpa[i-1,j]<-2
            dif<-dif+1
          }
          if(tmpa[i,j-1]==1) {
            tmpa[i,j-1]<-2
            dif<-dif+1
          }
        }
      }  
    }
  }
  z<-tmpa[(1:n)+1,(1:n)+1]
  return(z)
}
### ここまで関数の定義

### 50x50の2次元，4近傍の場で0.55の確率で抗体の無い人がいた場合
## 実験設定
n<-50
z<-immune(n,0.55) 
plot(z)

## 感染の可能性のある経路を表示
cluster(z)

## 1人感染したと仮定
idx<-outbreak(z)

## 感染の拡大を表示
w<-infection(z,idx)

## 罹患率(患者の数/抗体のない人)
print(sum(w==2)/sum(w>0))

### 50x50の2次元，4近傍の場で0.65の確率で抗体の無い人がいた場合
## 実験設定
z<-immune(n,0.65) 
plot(z)

## 感染の可能性のある経路を表示
cluster(z)

## 1人感染したと仮定
idx<-outbreak(z)

## 感染の拡大を表示
w<-infection(z,idx)

## 罹患率(患者の数/抗体のない人)
print(sum(w==2)/sum(w>0))

### 50x50の2次元，4近傍の場で様々な確率で実験
## 実験設定
n<-50
p<-seq(0.05,1,by=0.05) # 0.05刻みで抗体の無い人の率をシミュレート
m<-10 # 各10回の試行の平均と分散を求める
tmp<-matrix(0,length(p),m)

## 抗体のない確率と罹患率の関係をプロット
plot(0:1,0:1,type="n",xlab="non-immune rate",ylab="infection rate")

for(i in 1:length(p)) {
  for(j in 1:m) {
    z<-immune(n,p[i]) 
    idx<-outbreak(z,plot=F)
    w<-spread(z,idx)
    tmp[i,j]<-sum(w==2)/sum(w>0)
    points(p[i],tmp[i,j],col="blue")
  }
  tmpa<-mean(tmp[i,])
  tmpb<-sd(tmp[i,])
  points(p[i],median(tmp[i,]),pch=16,col="blue",cex=1.5)
  points(p[i],tmpa,pch=5,col="blue")
  segments(p[i],min(1,tmpa+tmpb),p[i],max(0,tmpa-tmpb),col="blue",lwd=2)
  segments(p[i]-.01,min(1,tmpa+tmpb),p[i]+.01,min(1,tmpa+tmpb),col="blue",lwd=2)
  segments(p[i]-.01,max(0,tmpa-tmpb),p[i]+.01,max(0,tmpa-tmpb),col="blue",lwd=2)
}
