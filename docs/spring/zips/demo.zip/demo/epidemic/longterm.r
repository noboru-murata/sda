###
### 感染症の長期的な性質の SIR model による実験
###

### SIR model による数値実験 
## S: susceptible 非感染者比率 (免疫がない)
## I: infected 感染者比率 (発症している)
## R: recovered 回復者比率 (免疫がある)
## これらの関係を連立微分方程式により記述
## dS/dt = -f(S,I)
## dI/dt =  f(S,I) - g(I)
## dR/dt =  g(I)

### 最も簡単なモデル
## dS/dt = -beta SI (非感染者の減少は非感染者と感染者の積に比例)
## dI/dt =  beta SI - gamma I (感染者は上記で増え，下記で減る)
## dR/dt =  gamma I (回復者は感染者のうち一定比率で増加)
f <- function(S,I){
    beta <- .2
    return(beta*S*I)
}
g <- function(I){
    gamma <- .1
    return(gamma*I)
}

## 実験設定
tmax <- 12*12 # 長さ (月ごとの離散化を想定)
S <- double(tmax)
I <- double(tmax)
R <- double(tmax)

## 初期状態 (いろいろ変えてもよい)
S[1] <- .3;I[1] <- .2;R[1] <- .5
## S[1] <- .5;I[1] <- .2;R[1] <- .3
## S[1] <- .8;I[1] <- .1;R[1] <- .1
for(t in 2:tmax){
    S[t] <- S[t-1] - f(S[t-1],I[t-1])
    I[t] <- I[t-1] + f(S[t-1],I[t-1]) - g(I[t-1])
    R[t] <- R[t-1] + g(I[t-1])
}

## 図示
plot(0,type="n",xaxt="n",
     xlim=c(0,tmax),ylim=c(0,1),
     xlab="time",ylab="ratio")
axis(1,at=seq(0,tmax,by=12),labels=0:(tmax/12))
lines(S,col="green",lwd=2)
lines(I,col="red",lwd=2)
lines(R,col="blue",lwd=2)
title("basic SIR model")
legend("topright",inset=.01,
       legend=c("Susceptible","Infected","Recovered"),
       lty="solid",lwd=2,col=c("green","red","blue"),
       bty="o",box.col="white")

### 忘却型 SIR model による数値実験
## 回復者の免疫が失われる効果を付加 (Sは非免疫者)
## dS/dt = -f(S,I) + h(R)
## dI/dt =  f(S,I) - g(I)
## dR/dt =  g(I) - h(R)

f <- function(S,I){
    beta <- .2
    return(beta*S*I)
}
g <- function(I){
    gamma <- .1
    return(gamma*I)
}
h <- function(R){
    alpha <- .05
    return(alpha*R)
}

## 実験設定
tmax <- 12*12 # 長さ (月ごとの離散化を想定)
S <- double(tmax)
I <- double(tmax)
R <- double(tmax)
## 初期状態 (いろいろ変えてもよい)
S[1] <- .3;I[1] <- .2;R[1] <- .5
## S[1] <- .5;I[1] <- .2;R[1] <- .3
## S[1] <- .8;I[1] <- .1;R[1] <- .1
for(t in 2:tmax){
    S[t] <- S[t-1] - f(S[t-1],I[t-1]) + h(R[t-1])
    I[t] <- I[t-1] + f(S[t-1],I[t-1]) - g(I[t-1])
    R[t] <- R[t-1] + g(I[t-1]) - h(R[t-1])
}

## 図示
plot(0,type="n",xaxt="n",
     xlim=c(0,tmax),ylim=c(0,1),
     xlab="time",ylab="ratio")
axis(1,at=seq(0,tmax,by=12),labels=0:(tmax/12))
lines(S,col="green",lwd=2)
lines(I,col="red",lwd=2)
lines(R,col="blue",lwd=2)
title("SIR model with oblivion")
legend("topright",inset=.01,
       legend=c("Susceptible","Infected","Recovered"),
       lty="solid",lwd=2,col=c("green","red","blue"),
       bty="o",box.col="white")

### 非線形 SIR model による数値実験
## f の項に非免疫者の数により感染率が変化する非線形効果を導入
## dS/dt = -f(S,I) + h(R)
## dI/dt =  f(S,I) - g(I)
## dR/dt =  g(I) - h(R)

f <- function(S,I){
    if(S<.6){
        beta <- .1
        return(beta*S*I)
    }else{
        beta <- .8
        return(beta*S)
    }        
}
g <- function(I){
    gamma <- .08
    return(gamma*I)
}
h <- function(R){
    alpha <- .04
    return(alpha*R)
}

## 実験設定
tmax <- 12*12 # 長さ (月ごとの離散化を想定)
S <- double(tmax)
I <- double(tmax)
R <- double(tmax)
## 初期状態 (いろいろ変えてもよい)
S[1] <- .3;I[1] <- .2;R[1] <- .5
## S[1] <- .5;I[1] <- .2;R[1] <- .3
## S[1] <- .8;I[1] <- .1;R[1] <- .1
for(t in 2:tmax){ # Euler近似で計算
    S[t] <- S[t-1] - f(S[t-1],I[t-1]) + h(R[t-1])
    I[t] <- I[t-1] + f(S[t-1],I[t-1]) - g(I[t-1])
    R[t] <- R[t-1] + g(I[t-1]) - h(R[t-1])
}

## 図示
plot(0,type="n",xaxt="n",
     xlim=c(0,tmax),ylim=c(0,1),
     xlab="time",ylab="ratio")
axis(1,at=seq(0,tmax,by=12),labels=0:(tmax/12))
lines(S,col="green",lwd=2)
lines(I,col="red",lwd=2)
lines(R,col="blue",lwd=2)
title("SIR model with non-linear effect")
legend("topright",inset=.01,
       legend=c("Susceptible","Infected","Recovered"),
       lty="solid",lwd=2,col=c("green","red","blue"),
       bty="o",box.col="white")

