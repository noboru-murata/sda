### 少数の法則
###    大きさ1の2項分布を使う
set.seed(123) # 乱数のシード値の指定
n <- 5000     # 1日の総生産量
p <- 0.002    # 不良品の発生確率
mc <- 5*50*2   # 実験回数(週5日x50週間x2年操業に対応)
x <- replicate(mc, sum(rbinom(n,1,p))) # 実験をmc回実行して不良品数を記録
(A <- table(x)) # 不良品数の度数分布表を作成
### それぞれの不良品数が生じた日数の割合のグラフを作成
par(family = "HiraginoSans-W4") # 日本語フォントの指定
plot(A/mc, type="h", col="royalblue", lwd=6, 
     xlab="不良品数", ylab="発生割合", main="少数の法則") 
lines(min(x):max(x)+0.4, dpois(min(x):max(x), n*p), type="h", 
      col="red", lwd=6) # 理論上の割合を上書き
legend("topright", inset=1/20, # 位置をキーワードで指定
       legend=c("観測値", "理論値"), 
       col=c("royalblue", "red"), lwd=4) # 凡例を作成
