(A <- matrix(1:9,nrow=3,ncol=3)) # 行列の作成(3x3行列)
det(A) # 行列式(determinant)の計算
sum(diag(A)) # トレース(trace)の計算
